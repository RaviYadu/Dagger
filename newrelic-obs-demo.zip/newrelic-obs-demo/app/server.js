'use strict'
const express = require('express')
const app = express()

app.get('/healthz', (req, res) => res.send('ok'))

app.get('/checkout', async (req, res) => {
  const delay = Math.floor(Math.random()*120)
  await new Promise(r => setTimeout(r, delay))
  if (Math.random() < 0.02) return res.status(500).send('random failure')
  res.json({ status: 'paid', latency_ms: delay })
})

app.listen(3000, () => console.log('API on :3000'))
